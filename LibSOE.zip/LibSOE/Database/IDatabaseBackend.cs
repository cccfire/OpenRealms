﻿namespace SOE.Database
{
    public interface IDatabaseBackend
    {
    }
}
